The program first stores every single node into a 2D vector of zonenodes called regionMap.
```cpp
vector<vector<zonenode *>> regionMap;
```
The reason we chose a 2D vector is because we believe that it is the best representation of a 2D city. It is much easier to conceptualize and work with.

Afterwards, the program connects a cell with their neighbors.
```cpp
for (int x = 0; x < regionMap.size(); x++)
    {
        for (int y = 0; y < regionMap[x].size(); y++)
        {
            zonenode *current = regionMap[x][y];
            current->setID(x * 100 + y);

            // Link north
            if (x - 1 >= 0)
            {
                current->setNeighbor(0, regionMap[x - 1][y]);

                // Link north west
                if (y - 1 >= 0)
                    current->setNeighbor(4, regionMap[x - 1][y - 1]);

                // Link north east
                if (y + 1 <= regionMap[x].size() - 1)
                    current->setNeighbor(5, regionMap[x - 1][y + 1]);
            }

            // Link south
            if (x + 1 <= regionMap.size() - 1)
            {
                current->setNeighbor(1, regionMap[x + 1][y]);

                // Link south west
                if (y - 1 >= 0)
                    current->setNeighbor(6, regionMap[x + 1][y - 1]);

                // Link south east
                if (y + 1 <= regionMap[x].size() - 1)
                    current->setNeighbor(7, regionMap[x + 1][y + 1]);
            }

            // Link west
            if (y - 1 >= 0)
                current->setNeighbor(2, regionMap[x][y - 1]);

            // Link east
            if (y + 1 <= regionMap[x].size() - 1)
                current->setNeighbor(3, regionMap[x][y + 1]);
        }
    }
```
The reason we decided to implement this linked list-esque aspect is to reduce neighbor lookup time and complexity. A neighbor lookup will always be constant, allowing us to easily determine a cell's adjacent population and whether it is powered or not.