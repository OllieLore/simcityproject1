This page talks about the ``Main.cpp`` file. Main.cpp is in charge of handling file input/output, creating the data structure, controlling the simulation, and calculating pollution.

First, for file i/o, it first inputs the config file and extracts the region file and simulation specs. Afterwards, it opens the region file, reads line by line and character by character. Whenever it reads a character, it figures out what type of zone it is using a switch statement and creates a respective object for it. It then pushes the new object into the 2D vector regionMap.
```cpp
    // File name input
    string filename;
    string csvfilename;
    ifstream filein;
    cin >> filename;

    // Open config file to store region csv, max time steps, and refresh rate
    filein.open(filename);
    if (filein.is_open())
    {
        cout << "Type config file name: " << endl;
        filein >> csvfilename;
        filein >> MAX_TIME_STEPS;
        filein >> REFRESH_RATE;

        cout << "MAX TIME STEPS: " << MAX_TIME_STEPS << endl;
        cout << "REFRESH RATE: " << REFRESH_RATE << endl;
    }
    else
    {
        cout << "Error opening config file" << endl;
    }
    filein.close();

    vector<zonenode *> row; // Row of grid
    string line, value;     // Input helper variables

    // Initial store into vectors
    fstream file(csvfilename, ios::in);
    if (file.is_open())
    {
        while (getline(file, line))
        {
            row.clear();

            stringstream str(line);

            while (getline(str, value, ','))
            {
                zonenode *toadd;
e main page of the program that calls both the files into this page and utilizes their functions to make the program work.
                // Determine what type of zone object to create
                switch (value[0])
                {
                case '-': // road
                    toadd = new zonenode(nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, '-', 0);
                    break;
                case 'T': // powerline
                    toadd = new zonenode(nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, 'T', 0);
                    break;
                case '#': // intersection
                    toadd = new zonenode(nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, '#', 0);
                    break;
                case 'P': // powerplant
                    toadd = new zonenode(nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, 'P', 0);
                    break;
                case 'I': // industrial
                    toadd = new industrialzone();
                    break;
                case 'R': // residential
                    toadd = new residentialzone();
                    break;
                case 'C': // commercial
                    toadd = new commercialzone();
                    break;
                default:
                    break;
                }

                row.push_back(toadd);
            }
            regionMap.push_back(row);
        }
    }
    else
    {
        cout << "Error opening region file" << endl;
    }
    file.close();
```

Second, Main.cpp links all of the nodes in regionMap together based off whether a node is a neighbor or not. The order it links is north, north west, north east, south, south west, south east, west, and finally east.
```cpp
    // Link all nodes
    for (int x = 0; x < regionMap.size(); x++)
    {
        for (int y = 0; y < regionMap[x].size(); y++)
        {
            zonenode *current = regionMap[x][y];
            current->setID(x * 100 + y);

            // Link north
            if (x - 1 >= 0)
            {
                current->setNeighbor(0, regionMap[x - 1][y]);

                // Link north west
                if (y - 1 >= 0)
                    current->setNeighbor(4, regionMap[x - 1][y - 1]);

                // Link north east
                if (y + 1 <= regionMap[x].size() - 1)
                    current->setNeighbor(5, regionMap[x - 1][y + 1]);
            }

            // Link south
            if (x + 1 <= regionMap.size() - 1)
            {
                current->setNeighbor(1, regionMap[x + 1][y]);

                // Link south west
                if (y - 1 >= 0)
                    current->setNeighbor(6, regionMap[x + 1][y - 1]);

                // Link south east
                if (y + 1 <= regionMap[x].size() - 1)
                    current->setNeighbor(7, regionMap[x + 1][y + 1]);
            }

            // Link west
            if (y - 1 >= 0)
                current->setNeighbor(2, regionMap[x][y - 1]);

            // Link east
            if (y + 1 <= regionMap[x].size() - 1)
                current->setNeighbor(3, regionMap[x][y + 1]);
        }
    }
```
Main.cpp then starts running the actual simulation. It first prints the initial region and every refresh cycle later, it calculates new population for the 3 major zones, calculates new pollution, prints out the new population/pollution stats, and allows for region analysis.
```cpp
 cout << "----------Step " << 0 << "----------" << endl;
    analyze(0, 0, regionMap[0].size(), regionMap.size());

    for (int a = 0; a < MAX_TIME_STEPS; a++)
    {
        cout << "----------Step " << a + 1 << "----------" << endl;

        // Calculate new commercial population
        for (int x = 0; x < regionMap.size(); x++)
        {
            for (int y = 0; y < regionMap[x].size(); y++)
            {
                if (regionMap[x][y]->getType() == 'C')
                {
                    commercialzone *tempInd = (commercialzone *)regionMap[x][y];
                    tempInd->increasePopulation();
                }
            }
        }

        // Calculate new industrial population
        for (int x = 0; x < regionMap.size(); x++)
        {
            for (int y = 0; y < regionMap[x].size(); y++)
            {
                if (regionMap[x][y]->getType() == 'I')
                {
                    industrialzone *tempInd = (industrialzone *)regionMap[x][y];
                    tempInd->increasePopulation();
                }
            }
        }

        // Calculate pollution
        for (int x = 0; x < regionMap.size(); x++)
        {
            for (int y = 0; y < regionMap[x].size(); y++)
            {
                if (regionMap[x][y]->getType() == 'I')
                {
                    spreadpollution(regionMap[x][y]->getPopulation(), x, y);
                }
            }
        }

        // Caluculate new residential population
        for (int x = 0; x < regionMap.size(); x++)
        {
            for (int y = 0; y < regionMap[x].size(); y++)
            {
                if (regionMap[x][y]->getType() == 'R')
                {
                    residentialzone *tempRes = (residentialzone *)regionMap[x][y];
                    tempRes->increasePopulation();
                }
            }
        }
        
        if (a % REFRESH_RATE == 0)
        {
            // Output entire city
            analyze(0, 0, regionMap[0].size(), regionMap.size());

            // Custom analyze
            customanalyze();
        }
    }
```