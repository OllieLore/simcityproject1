**The Task**

The program is a simulation of the growth and development a city. Simulating the growth of the population, the worker class and the pollution.

The city is split into 3 main zones: 
1. The [Residential](Residential Zone) zone.
2. The [Industrial](Industrial Zone) zone.
3. The [Commercial](Commercial Zone) zone.

In addition, the following files are used to tie the project together:
1. The [Zonenode.h](Zonenode.h) file.
2. The [Main.cpp](Main.cpp) file.
3. The [Pollution](Pollution) file.

The residential zone dictates how many workers can live in the city.

The industrial zone dictates how many goods can be produced. Workers are required to run industrial zones.

The commercial zone dictates how many goods can be sold. Both workers and goods are required to run commercial zones.

Our primary data structure is a 2D vector with aspects of a linked list. More details can be found [here](Data Structure).

![unnamed](uploads/0d63cb7ed52fa3eb1986a44254f4f298/unnamed.png)

![unnamed1](uploads/db9e372829ed722be1305b755f21f842/unnamed1.png)