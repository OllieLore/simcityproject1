This page is about the **`zonenode.h`** and it's functionality within the program as a whole.

`zonenode.h` serves as the program's major class function that gives the various 'directions' of a cell, which allows the functions within the other files to compare Neighbors.

```cpp
class zonenode
{
protected:
    // Zone type
    char type;

    // Misc. values
    int population, pollution, id /*id is 00x00y*/;
    int workers;
    // Neighbors
    zonenode *north;
    zonenode *south;
    zonenode *west;
    zonenode *east;
    zonenode *nwest;
    zonenode *neast;
    zonenode *swest;
    zonenode *seast;
```



```cpp
public:
    // Constructor
    zonenode(zonenode *n, zonenode *s, zonenode *w, zonenode *e, zonenode *nw, zonenode *ne, zonenode *sw, zonenode *se, char t, int i);

    zonenode();

    /*
        Set neighbor function, int l is the number equivalent of neighbor location
        0 - north
        1 - south
        2 - west
        3 - east
        4 - north west
        5 - north east
        6 - south west
        7 - south east
    */
    void setNeighbor(int l, zonenode *n);

    // Set zone type function
    void setType(char t);

    // Set population function
    void setPopulation(int p);

    // Set pollution function
    void setPollution(int p);

    //set available workers
    virtual void setWorkers(int population);

    //get available workers
    virtual int getWorkers();

    // Set id function
    void setID(int i);
    // Get neighbor function
    zonenode *getNeighbor(int l);

    // Get zone type function
    char getType();

    // Get population function
    int getPopulation();

    // Get pollution function
    int getPollution();

    // Get id function
    int getID();

    // toString function
    std::string toString();
};
```
The zonenode class is a superclass to the commercial zone, industrial zone, and residential zone class. The reason we decided to do this is to make it much easier to implement a 2D vector, which is explained in the [data structure](Data Structure) section.