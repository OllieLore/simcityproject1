**pollution**

Industrial zones produce pollution equal to their population. Pollution spreads outward in layers, with each layer's pollution value equal to one less than the preceding layer's pollution.

The function to spread pollution first spreads pollution from left to right before preceding top to bottom.

```cpp
void spreadpollution(int p, int x, int y)
{
    int centerx = x;
    int centery = y;

    int startx = x;
    int starty = y;

    for (int a = p; a > 0; a--)
    {
        // Spread left and right columns
        for (int b = starty; b <= starty + 2 * (p - a); b++)
        {
            if (b >= 0 && b <= regionMap.size())
            {
                if (centerx - (p - a) >= 0 && centerx - (p - a) <= regionMap[x].size() && a > regionMap[centerx - (p - a)][b]->getPollution())
                    regionMap[centerx - (p - a)][b]->setPollution(a);
                if (centerx - (p - a) != centerx + p - a && centerx + p - a >= 0 && centerx + p - a <= regionMap[x].size() && a > regionMap[centerx + p - a][b]->getPollution())
                    regionMap[centerx + p - a][b]->setPollution(a);
            }
        }

        // Spread top and bottom rows
        for (int b = startx + 1; b <= startx + 2 * (p - a) - 1; b++)
        {
            if (b >= 0 && b <= regionMap[x].size())
            {
                if (centery - (p - a) >= 0 && centery - (p - a) <= regionMap.size() && a > regionMap[b][centery - (p - a)]->getPollution())
                    regionMap[b][centery - (p - a)]->setPollution(a);
                if (centery + p - a >= 0 && centery + p - a <= regionMap.size() && a > regionMap[b][centery + p - a]->getPollution())
                    regionMap[b][centery + p - a]->setPollution(a);
            }
        }

        startx--;
        starty--;
    }
}
```