This page is about the **industrialzone** **.cpp** and **.h** files and their functionality within the program as a whole.

Within the program, **I** represents a *Industrial Zone*.

An Industrial Zone increases a zone's population when it first knows it is near a power line, then when it meets a certain worker count.

Firstly, we will talk about the **.h** file, which serves to set up the *industrialzone* class and it's **public** and **private** elements.

**industrialzone**

```.h file
#ifndef INDUSTRIALZONE_H
#define INDUSTRIALZONE_H
#include "zonenode.h"
#include <string>
#include "residentialzone.h"

using namespace std;

class industrialzone : public zonenode {
    public:

	static int availableWorkers; //static variable for available workers between classes
	static int availableGoods; //static variable for available goods between classes
	int workerCount;
	int industrialPopulation;
	zonenode *temp;
	bool power;
	bool pop;
	bool workers;
	int neighborPopCount1;
	int neighborPopCount2;
	residentialzone *tempR;
	
  
        industrialzone(); //constructor
	void SetPopulation(int industrialPopulation);
	int GetAvailableGoods(); //get good #
	void SetAvailableGoods(int availableGoods); //set good #
	int GetWorkerCount(); 
	void SetWorkerCount(int workerCount);
	void CheckPower(); //check if cell powered
	void CheckWorkerCount(); //check if workers available
	void IncreasePopulation(bool power, bool pop, bool workers); //increase population of zone
	void CheckNeighborPopulation(); //check population growth criteria
	int IncreaseGoods(bool power, bool pop, bool workers); //increase goods
	bool GetPower();
	bool GetPop();
	bool GetWorkers();

};

#endif
```

_Private_:

I decided to keep all variables public for the industrialzone class. 

_Public_:
- static int availableWorkers
      -static variable for available workers between classes
- static int availableGoods
      -static variable for available goods between classes
- int workerCount
      -variable to keep track of workers
- int industrialPopulation
      -variable to keep track of industrial population
- zonenode *temp
      -temporary pointer to access the functions of the other classes
- bool power
      -bool to determine if requirement for power is met
- bool pop
      -bool to determine if requirement for adjacent populated zones is met
- bool workers
      -bool to determine if requirement for available workers is met
- int neighborPopCount1
      -counter for zones with one or more population
- int neighborPopCount2
      -counter for zones with two or more population
- residentialzone *tempR
      -temporary pointer to access residential class
	
  
- industrialzone()
      -constructor
- void SetPopulation(int industrialPopulation)
      -setter to set the population
- int GetAvailableGoods()
      -function to get number of available goods
- void SetAvailableGoods(int availableGoods)
      -function to set the number of available goods
- int GetWorkerCount()
      -function to get the number of available workers
- void SetWorkerCount(int workerCount)
      -function to set the amount of available workers
- void CheckPower()
      -function to check if zone is powered
- void CheckWorkerCount()
      -function to check if enough workers are available
- void IncreasePopulation(bool power, bool pop, bool workers)
      -function to increase (or not increase) the population of the zone during a timestep
- void CheckNeighborPopulation()
      -function to check population adjacency growth criteria
- int IncreaseGoods(bool power, bool pop, bool workers)
      -function to increase (or not increase) the goods of the zone during a timestep
- bool GetPower()
      -function to determine power status of a zone
- bool GetPop()
      -function to determine population adjacency of a zone
- bool GetWorkers()
      -function to determine worker availability of a zone

```.cpp file
#include "industrialzone.h"
#include "zonenode.h"
#include <string>
#include "residentialzone.h"
#include "industrialzone.h"
#include <iostream>

using namespace std;
int industrialzone::availableGoods = 0; //static variable to keep track of goods across classes

//Constructor
industrialzone::industrialzone() : zonenode::zonenode(nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, 'I', 0) {
industrialPopulation = 0;
availableGoods = 0;
workerCount = 0;
temp = nullptr;  
power = true; //bool for if zone is powered
pop = true; //bool for adjacent populated zone check
workers = true; //bool for available workers
neighborPopCount1 = 0;
neighborPopCount2 = 0;
}

	
void industrialzone::SetPopulation(int industrialPopulation){
    industrialPopulation = industrialPopulation;
}
	
int industrialzone::GetAvailableGoods(){
        return availableGoods; 
    }
	
void industrialzone::SetAvailableGoods(int availableGoods){
    this->availableGoods = availableGoods;
}
	
int industrialzone:: GetWorkerCount(){
    return workerCount;
}
	
void industrialzone::SetWorkerCount(int workerCount){
    this->workerCount = workerCount;
}

    bool industrialzone::GetPower(){
    return power;
}
	bool industrialzone::GetPop(){
        return pop;
    }
    
	bool industrialzone::GetWorkers(){
        return workers;
    }	

//Grow zone population
void industrialzone::IncreasePopulation(bool power, bool pop, bool workers){ 
    if(power == true && workers == true || pop == true && workers == true){
            cout << "true" << endl;
    population = population + 1;
    
        
    }

}

//Increase commercial goods
int industrialzone::IncreaseGoods(bool power, bool pop, bool workers){
    if(power == true && pop == true && workers == true){
    availableGoods = availableGoods +1;
    return availableGoods;
    }
    else{
        return availableGoods;
    }
}
    //check if zone is powered    
void industrialzone::CheckPower(){
    for(int i = 0; i < 8; i++){


        if(getNeighbor(i) != nullptr){

        if(getNeighbor(i)->getType() == '#'){
            power= true;
            break;
        } 
        if(getNeighbor(i)->getType() == 'T'){
            cout << "hello";
            power= true;
            break;
        }
        if(getNeighbor(i)->getType() == 'P'){
         power= true;
         break;

    }

    else{
        power = false;
    }

        }
    
    }
}
//function to check adjacent zone population criteria for growth
void industrialzone::CheckNeighborPopulation(){
    pop = false;

    for(int i = 0; i < 8; i++){

        
    if(getNeighbor(i) != nullptr){        
    if(getNeighbor(i)->getPopulation() >= 1){
        neighborPopCount1++;

    }
    if(getNeighbor(i)->getPopulation() >= 2){
        neighborPopCount2++;
    }
    }


     if(industrialPopulation == 0 && neighborPopCount1 >=1){
        pop = true;
     }
     if(industrialPopulation == 0 && neighborPopCount1 >=2){
        pop = true;
     }
     if(industrialPopulation == 0 && neighborPopCount2 >=4){
        pop = true;
     }
    }
}


//function to check available workers
void industrialzone::CheckWorkerCount(){

    
    if(residentialzone::getWorkers() >= 2){
        workers = true;
        residentialzone::setWorkers(residentialzone::getWorkers()-2);
        }
    else{
        workers = false;
    }


}
```

Here are the functions that return the population and worker counts for the zone. `GetPopulation` working to keep track of the population of the node, and `SetPopulation` updating it.

The goods produced are also kept track of, using `GetAvailableGoods` and `SetAvailableGoods` respectively.

```     
  //check if zone is powered    
void industrialzone::CheckPower(){
    for(int i = 0; i < 8; i++){


        if(getNeighbor(i) != nullptr){

        if(getNeighbor(i)->getType() == '#'){
            power= true;
            break;
        } 
        if(getNeighbor(i)->getType() == 'T'){
            cout << "hello";
            power= true;
            break;
        }
        if(getNeighbor(i)->getType() == 'P'){
         power= true;
         break;

    }

    else{
        power = false;
    } 
}}}
```

Within this void and for loop, the neighbors are compared and when a power line is found, the `power` bool is flipped to true.

```
//function to check adjacent zone population criteria for growth
void industrialzone::CheckNeighborPopulation(){
    pop = false;

    for(int i = 0; i < 8; i++){

        
    if(getNeighbor(i) != nullptr){        
    if(getNeighbor(i)->getPopulation() >= 1){
        neighborPopCount1++;

    }
    if(getNeighbor(i)->getPopulation() >= 2){
        neighborPopCount2++;
    }
    }


     if(industrialPopulation == 0 && neighborPopCount1 >=1){
        pop = true;
     }
     if(industrialPopulation == 0 && neighborPopCount1 >=2){
        pop = true;
     }
     if(industrialPopulation == 0 && neighborPopCount2 >=4){
        pop = true;
     }}}
```

Within this for loop, the populations of neighbor zones are compared, and make the bool variable pop true is the criteria for growth is met.

Criteria for industrial zone growth is:

- If a cell has a population of 0, is adjacent to a powerline in the current time step, and there are at least 2 available workers, that cell’s population will increase by 1 in the next time step and the available workers are assigned to that job.
    - If a cell has a population of 0, is adjacent to at least one cell with a population of at least 1, and there are at least 2 available workers, that cell’s population will increase by 1 in the next time step and the available workers are assigned to that job.
    - If a cell has a population of 1, is adjacent to at least two cells with a population of at least 1, and there are at least 2 available workers, that cell’s population will increase by 1 in the next time step and the available workers are assigned to that job.
    - If a cell has a population of 2, is adjacent to at least four cells with a population of at least 2, and there are at least 2 available workers, that cell’s population will increase by 1 in the next time step and the available workers are assigned to that job.
    - A cell produces pollution equal to its population, and pollution spreads to all adjacent cells at a rate of one less unit of pollution per cell away from the source.

```
//Grow zone population
void industrialzone::IncreasePopulation(bool power, bool pop, bool workers){ 
    if(power == true && workers == true || pop == true && workers == true){
            cout << "true" << endl;
    population = population + 1;
   }}
```

Here, the function gets information of the population of the neighboring cells or if it is near a power line along with having the required workers to grow.

```
   //function to check available workers
void industrialzone::CheckWorkerCount(){

    
    if(residentialzone::getWorkers() >= 2){
        workers = true;
        residentialzone::setWorkers(residentialzone::getWorkers()-2);
        }
    else{
        workers = false;
    }


}
```
Here the function checks for available workers and if enough workers are available it calls to reduce the amount of available workers within the city of zones. 

In this switch list, it compares if the population of a zone reaches the criteria listed below:


    

```
void industrialzone::SetAvailableGoods(int availableGoods){
    this->availableGoods = availableGoods;
}

int industrialzone::getAvailableGoods() {
    return availableGoods;
}
```

These functions are getters and setters for available goods that can be called in other classes like commercial.