This page is about the **commercialzone** **.cpp** and **.h** files and their functionality within the program as a whole.

Within the program, **C** represents a _Commercial Zone_.

A Commercial Zone works similar to a Residential Zone, only the population produces a good:

- If a cell has a population of 0, is adjacent to a powerline in the current time step, there is at least 1 available worker, and there is at least one available good, that cell’s population will increase by 1 in the next time step and the available worker and available good are assigned to that job.
- f a cell has a population of 0, is adjacent to at least one cell with a population of at least 1, there is at least 1 available worker, and there is at least one available good, that cell’s population will increase by 1 in the next time step and the available worker and available good are assigned to that job.
- If a cell has a population of 1, is adjacent to at least two cells with a population of at least 1, there is at least 1 available worker, and there is at least one available good, that cell’s population will increase by 1 in the next time step and the available worker and available good are assigned to that job.

First, we will take a look at the **.h** file and it's **public** and **private** elements:

```cpp
#ifndef COMMERCIALZONE_H
#define COMMERCIALZONE_H

#include "zonenode.h"

class commercialzone : public zonenode {
    private:
        int futurePop;
    public:
        // Constructor
        commercialzone();

        //getters and setters
        int GetFuturePop();

        void SetFuturePop(int futurePopI);

        // Checks neighbor poulation to see if they meet requirements
        bool NeighborPopulationCheck(int popMin, int neighborAmount);
        void ComercialTimeStep();

        void increasePopulation();
};


#endif
```

_Private_:

- `futurePop` serves as the variable that will keep track of populations in future timestamps.

_Public_:
- `commercialzone();` serves as the class constructor, and gives the **.cpp** file the functionality to call upon this class.
- `GetFuturePop();` updates the population within each time step.
- `SetFuturePop` serves to increment the future population.
- `NeighborPopulationCheck` checks the minimum population count and the neighbor amount to check if they meet the criteria to grow the population of the cell.
- `increasePopulation` increases the population when `NeighborPopulationCheck` is confirmed.


Next, we shall take a look at the **.cpp** file:

```cpp
#include "commercialzone.h"
#include "residentialzone.h"
#include "industrialzone.h"
#include "zonenode.h"
#include <iostream>

#include <vector>
#include <algorithm>

using namespace std;

commercialzone::commercialzone() : zonenode::zonenode(nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, 'C', 0) {}

void commercialzone::increasePopulation() {
    vector<int> tempPop;
    bool isPowered = false;
```

Firstly, we can see that `zonenode.h` is called upon for the functionality to check the cell's adjacent neighbors to determine if they meet the criteria to increase the population of the cell.

In addition, `commercialzone` calls upon `zonenode` to utilize the function to check the surrounding neighbors, and confirm that they meet the criteria to grow the cell's population.

```
    //Gets information on neighbors' population and whether current residential zone is powered
    for(int x = 0; x < 8; x++) {
        zonenode *temp = getNeighbor(x);

        if(temp != nullptr)
            switch(temp->getType()) {
                case 'T':
                    isPowered = true;
                    break;
                case '#':
                    isPowered = true;
                    break;
                case 'I':
                    tempPop.push_back(temp->getPopulation());
                    break;
                case 'C':
                    tempPop.push_back(temp->getPopulation());
                    break;
                case 'R':
                    tempPop.push_back(temp->getPopulation());
                    break;
                default:
                    break;
            }
    }
```
Similarly to the Residential Zone, this switch case checks the surrounding neighbors to determine if they meet the criteria to increase the population and worker size.

```
    if(residentialzone::getAvailableWorkers() >= 1 && industrialzone::getAvailableGoods() >= 1) {
        switch(this->getPopulation()) {
            case 0:
                if(count(tempPop.begin(), tempPop.end(), 1) >= 1) {
                    this->setPopulation(this->getPopulation() + 1);
                    residentialzone::decreaseAvailableWorkers(1);
                    industrialzone::decreaseAvailableGoods(1);
                }
                else if(isPowered) {
                    this->setPopulation(this->getPopulation() + 1);
                    residentialzone::decreaseAvailableWorkers(1);
                    industrialzone::decreaseAvailableGoods(1);
                }
                break;
            case 1:
                if(count(tempPop.begin(), tempPop.end(), 1) >= 2) {
                    this->setPopulation(this->getPopulation() + 1);
                    residentialzone::decreaseAvailableWorkers(1);
                    industrialzone::decreaseAvailableGoods(1);
                }
                break;
            default:
                    break;
        }
    }
}
```

Within this if statement, we check if the population and available goods are above 1, and if that be the case, we decrease the goods and population count as the goods will be given to the zone.

```
//updates population
void commercialzone::UpdatePop()
{
    population = GetFuturePop();
}
```

Finally, the `commercialzone::UpdatePop` function updates the population count of the zone within each time step.