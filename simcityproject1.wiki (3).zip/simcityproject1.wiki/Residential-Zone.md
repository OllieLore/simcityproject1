This page is about the **residentialzone** **.cpp** and **.h** files and their functionality within the program as a whole.

Within the program, **R** represents a _Residential Zone_. 

A Residential Zone increases in population when it first knows it is near a power line, then when it meets a certain population count. 

In addition, it hands over a number of workers to both _Industrial_ and _Commercial_ functions.

Firstly, we will talk about the **.h** file, which serves to set up the _residentialzone_ class and it's **public** and **private** elements.

```cpp
#ifndef RESIDENTIALZONE_H
#define RESIDENTIALZONE_H

#include "zonenode.h"

class residentialzone : public zonenode {
    private:
        static int availableWorkers;
    public:
        //Constructor
        residentialzone();

        //Mutator
        void increasePopulation();

        static void decreaseAvailableWorkers(int n);

        //Accessor
        static int getAvailableWorkers();
};

#endif
```

_Private:_
- `static int availableWorkers;` serves as the variable that will keep track of the available workers in the Residential Zone.

_Public:_
- `residentialzone();` serves as the class constructor, and gives the **.cpp** file the functionality to call upon this class.
- `void increasePopulation();` serves to increase the population size of the cell when the cell meets the correct criteria.
- `static void decreaseAvailableWorkers(int n);` serves to decrease the amount of workers when the workers are given to the **Industrial** or the **Commercial** zones.
- `static int getAvailableWorkers();` serves as the accessor, which keeps track of the worker population during each time step.



Next, we shall take a look at the **.cpp** file:

```cpp
#include "residentialzone.h"
#include "zonenode.h"

#include <vector>
#include <algorithm>

using namespace std;

int residentialzone::availableWorkers = 0;

residentialzone::residentialzone() : zonenode::zonenode(nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, 'R', 0) {}
```

Firstly, we can see that we call upon `"zonenode.h"` for the functionality to check the cell's adjacent neighbors to determine if they meet the criteria to increase the population of the cell.

In addition, we can see from `int residentialzone::availableWorkers = 0;`, it inherits the `availableWorkers` variable from the **.h** file and sets it to 0 by default.

Next, we can see `residentialzone::residentialzone() : zonenode::zonenode(nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, 'R', 0) {}`, which is inherited from `zonenode.h`, this gives the Residential Zone the ability to check it's surrounding neighbors to determine if they meet the criteria to increase the population and worker size.


```cpp
void residentialzone::increasePopulation() {
    vector<int> tempPop;
    bool isPowered = false;

    //Gets information on neighbors' population and whether current residential zone is powered
    for(int x = 0; x < 8; x++) {
        zonenode *temp = getNeighbor(x);

        if(temp != nullptr)
            switch(temp->getType()) {
                case 'T':
                    isPowered = true;
                    break;
                case '#':
                    isPowered = true;
                    break;
                case 'I':
                    tempPop.push_back(temp->getPopulation());
                    break;
                case 'C':
                    tempPop.push_back(temp->getPopulation());
                    break;
                case 'R':
                    tempPop.push_back(temp->getPopulation());
                    break;
                default:
                    break;
            }
    }

```

Here is the `increasePopulation()` function, which inherits `zonenode.h`'s ability to check the neighboring cells.

In addition, `vector<int> tempPop;` stores the population and `bool isPowered = false;` is off by default, as it doesn't know if the cell is near a power-line.


```cpp
    for(int x = 0; x < 8; x++) {
        zonenode *temp = getNeighbor(x);

        if(temp != nullptr)
            switch(temp->getType()) {
                case 'T':
                    isPowered = true;
                    break;
                case '#':
                    isPowered = true;
                    break;
                case 'I':
                    tempPop.push_back(temp->getPopulation());
                    break;
                case 'C':
                    tempPop.push_back(temp->getPopulation());
                    break;
                case 'R':
                    tempPop.push_back(temp->getPopulation());
                    break;
                default:
                    break;
            }
    }
```

This for loop checks if the population within the cells surrounding the current one is 1) Near a powerline, and 2) If it isn't and is near another zone, it ignores the cell and moves on.

```cpp
    //Do all the incrementing
    switch(this->getPopulation()) {
        case 0:
            if(count(tempPop.begin(), tempPop.end(), 1) >= 1) {
                this->setPopulation(this->getPopulation() + 1);
                availableWorkers++;
            }
            else if(isPowered) {
                this->setPopulation(this->getPopulation() + 1);
                availableWorkers++;
            }
            break;
        case 1:
            if(count(tempPop.begin(), tempPop.end(), 1) >= 2) {
                this->setPopulation(this->getPopulation() + 1);
                availableWorkers++;
            }
            break;
        case 2:
            if(count(tempPop.begin(), tempPop.end(), 2) >= 4) {
                this->setPopulation(this->getPopulation() + 1);
                availableWorkers++;
            }
            break;
        case 3:
            if(count(tempPop.begin(), tempPop.end(), 3) >= 6) {
                this->setPopulation(this->getPopulation() + 1);
                availableWorkers++;
            }
            break;
        case 4:
            if(count(tempPop.begin(), tempPop.end(), 4) >= 8) {
                this->setPopulation(this->getPopulation() + 1);
                availableWorkers++;
            }
            break;
        default:
                break;
    }
}
```

In this for loop, is where all the incrementing happens!

This loop follows this increasingly complex incrementing pattern:

    - If a cell's population is 0 and is adjacent to a powerline in the current time step, that cell’s population will increase by 1 in the next time step.
    - Next, if the cell's population is 0 and is adjacent to at least one cell with a population of at least 1, that cell’s population will increase by 1 in the next time step.
    - Then, if a cell has a population of 1 and is adjacent to at least two cells with a population of at least 1, that cell’s population will increase by 1 in the next time step.
    - Nextly, if a cell has a population of 2 and is adjacent to at least four cells with a population of at least 2, that cell’s population will increase by 1 in the next time step.
    - Then, If a cell has a population of 3 and is adjacent to at least six cells with a population of at least 3, that cell’s population will increase by 1 in the next time step.
    - Finally, if a cell has a population of 4 and is adjacent to at least eight cells with a population of at least 4, that cell’s population will increase by 1 in the next time step.

```cpp
void residentialzone::decreaseAvailableWorkers(int n) {
    availableWorkers -= n;
}

int residentialzone::getAvailableWorkers() {
    return availableWorkers;
}
```

In addition to keeping track of the growing population, the Residential Zone gives a worker to the industrial and commercial zones.

`decreaseAvailableWorkers` decreases the worker population when the worker is given to one of the zones.

`getAvailableWorkers` updates the worker population within each time step.