Members: Olive Davis, Mark Nikirk, William Hua, Elijah Haynes

To Know:
a) add config file, csv file and zonenode.h, zonenode.cpp, main.cpp to the same directory
b) source code in GitLab for zonenode.h, zonenode.cpp, main.cpp on Olive's branch

How to Compile:
    1. Open Console
    2. g++ *.cpp
    3. ./a.out
    4. input config file name

How to Run:
    1. Open Console
    2. Type "g++ *.cpp" into the terminal window
    3. Afterwards, type "./a.out" into the terminal window
    4. Input name of the Config file you wish to use
